<?php

session_start();

// Prevent direct access unless coming from index.php
if (!isset($_SESSION['access_granted'])) {
    header("Location: index.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    echo "Rebooting...";
    shell_exec('sudo /sbin/reboot');
} else {
    echo '<form method="POST"><button type="submit">Reboot Pi</button></form>';
}
?>