<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Redirect user BEFORE running reboot
    header("Location: waiting.php");
    header("Connection: close");
    header("Content-Length: 0");
    ob_flush();
    flush();

    // Wait to ensure the browser loads waiting.php before rebooting
    sleep(3);

    // Now safely execute the reboot command
    shell_exec('sudo /sbin/reboot');
    exit;
}
?>