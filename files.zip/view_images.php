<?php
session_start();

// Prevent direct access to the page
// access_granted is set on index.php after session_start();
if (!isset($_SESSION['access_granted'])) {
    header("Location: index.php");
    exit;
}

// Validate referer to ensure it comes from the expected source
$allowedReferer = 'index.php';
if (strpos($_SERVER['HTTP_REFERER'], $allowedReferer) === false) {
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="favicon.ico">
    <title>Slideshow - View Images</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    
<style>
    body{background-color:#121212;color:#fff}
    .image-container{margin-bottom:20px}
    .image-container img{max-width:100%;height:auto;border:2px solid #444;border-radius:10px}
    .image-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:20px}
    .modal-title{color:#000}
</style>

</head>
<body>
    <div class="container mt-4 mb-5">
        <h1 class="text-center">Uploaded Images</h1>
        <div class="container mt-4 text-center">
            <a href="index.php" class="btn btn-primary btn-lg"><strong>Go Home</strong></a>
        </div>

        <div class="image-grid">
            <?php
            ini_set('display_errors', 1);
            error_reporting(E_ALL);

            $directory = __DIR__ . '/slideshow/';
            if (!is_dir($directory)) {
                echo '<p class="text-center">Error: Slideshow folder not found.</p>';
            } else {
                $files = array_filter(scandir($directory), function ($file) {
                    return preg_match('/\.(jpg|jpeg|png|gif)$/i', $file);
                });

                if ($files) {
                    foreach ($files as $fileName) {
                        echo '<div class="image-container mt-4 mb-4">';
                        echo '<p><strong>Image Name:</strong> ' . htmlspecialchars($fileName, ENT_QUOTES, 'UTF-8') . '</p>';
                        echo '<a href="#" data-bs-toggle="modal" data-bs-target="#imageModal" data-bs-image="slideshow/' . htmlspecialchars($fileName, ENT_QUOTES, 'UTF-8') . '">';
                        echo '<img src="slideshow/' . htmlspecialchars($fileName, ENT_QUOTES, 'UTF-8') . '" alt="' . htmlspecialchars($fileName, ENT_QUOTES, 'UTF-8') . '" class="img-thumbnail" style="max-width: 300px;">';
                        echo '</a>';
                        echo '</div><br><br>';
                    }
                } else {
                    echo '<p class="text-center">No valid images found.</p>';
                }
            }
            ?>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="imageModal" tabindex="-1" aria-labelledby="imageModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="imageModalLabel">Image Preview</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <img src="placeholder.jpg" alt="" id="modalImage" class="img-fluid">
                </div>
            </div>
        </div>
    </div>

    <script>
        // JavaScript to update modal with clicked image
        document.addEventListener('DOMContentLoaded', function () {
            document.querySelectorAll('a[data-bs-toggle="modal"]').forEach(function (element) {
                element.addEventListener('click', function (e) {
                    e.preventDefault();
                    var imageSrc = element.getAttribute('data-bs-image');
                    var imageName = imageSrc.split('/').pop(); // Extract filename
                    document.getElementById('modalImage').src = imageSrc;
                    document.getElementById('imageModalLabel').textContent = imageName; // Update modal title
                });
            });
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js"></script>
</body>
</html>
