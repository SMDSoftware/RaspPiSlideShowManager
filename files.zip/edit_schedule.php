<?php
session_start();

// Prevent direct access to the page
// access_granted is set on index.php after session_start();
if (!isset($_SESSION['access_granted'])) {
    header("Location: index.php");
    exit;
}


// File path for the deletion schedule
$file = 'deletion_schedule.txt';
$error = false;
$message = "";

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['content'])) {
    $lines = array_filter(array_map('trim', explode("\n", $_POST['content'])));
    $valid = true;

    foreach ($lines as $line) {
        if (!preg_match('/^[^|]+\.(jpg|jpeg|png|gif)\|\d{4}-\d{2}-\d{2}$/i', $line)) {
            $valid = false;
            break;
        }
    }

    if ($valid) {
        $content = implode("\n", $lines);
        if (file_put_contents($file, $content) === false) {
            $message = "Error: Unable to save changes.";
            $error = true;
        } else {
            $message = empty($content) ? "Deletion schedule cleared and saved successfully." : "Deletion schedule successfully updated!";
        }
    } else {
        $message = "Error: One or more lines have an invalid format. Expected format: filename.jpg|YYYY-MM-DD. Certain issues may have been automatically corrected.";
        $error = true;
    }
}


// Load file content if exists
$content = file_exists($file) ? file_get_contents($file) : "";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="favicon.ico">
    <title>Edit Deletion Schedule</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    

<style>
body { background-color: #121212; color: white; }
  .card-text code.code-bold {
    font-weight: bold !important;
  }
.card { background-color: #1e1e1e; }
.card-title, .card-body { color: white; }
.btn-dark { background-color: #333; border-color: #444; }
.alert { margin-top: 10px; }
img { max-width: 100%; height: auto; }

</style>

</head>
<body class="container mt-4">

    <div class="card">
        <div class="card-body">
            <h5 class="card-title"><strong>Edit Deletion Schedule</strong></h5>
            <p class="card-text">Edit this file to manually update deletion dates or add missed dates:</p>
            <p class="card-text"><strong>Format:</strong> <code class="code-bold">image_filename.jpg|YYYY-MM-DD</code></p>

            <form method="POST">
                <div class="mb-3">
                    <label for="content" class="form-label"><strong>Edit Schedule:</strong></label>
                    <textarea id="content" name="content" class="form-control" rows="10"><?php echo htmlspecialchars($content, ENT_QUOTES, 'UTF-8'); ?></textarea>
                </div>
                <button type="submit" class="btn btn-success"><strong>Save Changes</strong></button>
                <a href="index.php" class="btn btn-secondary"><strong>Home</strong></a>
            </form>
        </div>
    </div>

    <?php if (!$error && $message): ?>
        <div class="alert alert-success mt-3"><?php echo htmlspecialchars($message, ENT_QUOTES, 'UTF-8'); ?></div>
    <?php endif; ?>

    <!-- Error Modal -->
    <div class="modal fade" id="errorModal" tabindex="-1" aria-labelledby="errorModalLabel" aria-hidden="true" data-bs-backdrop="static">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content bg-danger text-white">
                <div class="modal-header">
                    <h5 class="modal-title" id="errorModalLabel"><strong>Error</strong></h5>
                </div>
                <div class="modal-body">
                    <p><?php echo htmlspecialchars($message, ENT_QUOTES, 'UTF-8'); ?></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal"><strong>Close</strong></button>
                </div>
            </div>
        </div>
    </div>

    <?php if ($error): ?>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            var errorModal = new bootstrap.Modal(document.getElementById("errorModal"));
            errorModal.show();
        });
    </script>
    <?php endif; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js"></script>

</body>
</html>