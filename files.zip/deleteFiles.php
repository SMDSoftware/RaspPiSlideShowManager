<?php
// deleteFiles.php
function deleteFilesBasedOnDate($imageDirectory, $scheduleFile) {
    $today = date('Y-m-d');  // Get today's date
    //$filePath = $directory . '/' . $scheduleFile;
	$filePath = $scheduleFile;

    // Debugging: Output today's date to JavaScript console
    echo "<script>console.log('Today\'s date: " . $today . "');</script>";

    // Check if the schedule file exists
    if (file_exists($filePath)) {
        $lines = file($filePath, FILE_IGNORE_NEW_LINES);
        $newLines = []; // To store updated lines after deletion
        
        foreach ($lines as $line) {
            list($file, $deleteDate) = explode('|', $line);  // Split filename and deletion date

            // Debugging: Output each line read from the file to JavaScript console
            echo "<script>console.log('Checking line: " . $file . " | " . $deleteDate . "');</script>";
            
            // Check if the deletion date matches today's date
            if ($deleteDate == $today) {
                $fileToDelete = $imageDirectory . '/' . $file;
                
                // Delete the file if it exists
                if (file_exists($fileToDelete)) {
                    if (unlink($fileToDelete)) {
                        echo "<script>console.log('Deleted: " . $file . "');</script>";
                    } else {
                        echo "<script>console.log('Error deleting file: " . $file . "');</script>";
                    }
                } else {
                    echo "<script>console.log('File not found: " . $file . "');</script>";
                }
            } else {
                // If the line doesn't match today's date, add it to the newLines array
                $newLines[] = $line;
            }
        }

        // After deleting files, update the schedule file to remove the deleted entries
        file_put_contents($filePath, implode("\n", $newLines) . "\n");
    } else {
        echo "<script>console.log('No deletion schedule found.');</script>";
    }
}

// Path to the directory where images are stored
$imageDirectory = __DIR__ . '/slideshow';  // Update with the actual path to the slideshow folder
$scheduleFile = __DIR__ . '/deletion_schedule.txt';  // Text file with the schedule

// Perform the deletion check
deleteFilesBasedOnDate($imageDirectory, $scheduleFile);
?>
