<?php
// Enable error reporting for debugging (optional)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Get the delay setting from the delay.txt file (default to 6000ms if not set)
$delay = 6000; // Default value of 6000ms (6 seconds)
$delayFile = __DIR__ . '/delay.txt';  // Full path to delay.txt
if (file_exists($delayFile)) {
    $delay = (int) file_get_contents($delayFile) * 1000; // Convert seconds to milliseconds
}

// Get the transition setting from the transitions.txt file
$transition = 2; // Default value (fade)
$transitionFile = __DIR__ . '/transitions.txt'; // Full path to transitions.txt
if (file_exists($transitionFile)) {
    $transition = (int) file_get_contents($transitionFile); // Read transition value
}




?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Slideshow</title>
  
<style>

  body {
    margin: 0;
    background: #fff; /* Set background to white */
  }

  .slideshow-container {
    position: relative;
    width: 100vw;
    height: 100vh;
    overflow: hidden;
  }

  .slideshow-container img {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 100%;
    height: auto;
    max-height: 105%;
    object-fit: cover;
    object-position: center;
    opacity: 0;
    
    /* Default transition (reset for all images) */
    transition: none;

    /* Fade Transition */
    <?php if ($transition === 2): ?>
    transition: opacity 1s ease-in-out;
    <?php endif; ?>

    /* Wipe from Right */
    <?php if ($transition === 3): ?>
    left: 100%; /* Start off-screen to the right */
    opacity: 1; /* Ensure it's visible during transition */
    transition: left 1s ease-in-out;
    <?php endif; ?>

    /* Wipe from Left */
    <?php if ($transition === 4): ?>
    left: -100%; /* Start off-screen to the left */
    opacity: 1;
    transition: left 1s ease-in-out;
    <?php endif; ?>

    /* Wipe from Top */
    <?php if ($transition === 5): ?>
    top: -100%; /* Start off-screen above */
    opacity: 1;
    transition: top 1s ease-in-out;
    <?php endif; ?>

    /* Wipe from Bottom */
    <?php if ($transition === 6): ?>
    top: 100%; /* Start off-screen below */
    opacity: 1;
    transition: top 1s ease-in-out;
    <?php endif; ?>
  }

  .slideshow-container img.visible {
    opacity: 1;
    z-index: 2; /* Ensure the new image is above the old one */

    /* Fade effect (already handled by opacity) */
    
    /* Wipe from Right */
    <?php if ($transition === 3): ?>
    left: 50%; /* Move into place */
    transform: translate(-50%, -50%);
    <?php endif; ?>

    /* Wipe from Left */
    <?php if ($transition === 4): ?>
    left: 50%;
    transform: translate(-50%, -50%);
    <?php endif; ?>

    /* Wipe from Top */
    <?php if ($transition === 5): ?>
    top: 50%;
    transform: translate(-50%, -50%);
    <?php endif; ?>

    /* Wipe from Bottom */
    <?php if ($transition === 6): ?>
    top: 50%;
    transform: translate(-50%, -50%);
    <?php endif; ?>
  }

  .slideshow-container img.previous {
    opacity: 0; /* Hide previous image */
    z-index: 1;

    /* Wipe from Right */
    <?php if ($transition === 3): ?>
    left: -100%; /* Move out to the left */
    transition: none; /* Instantly remove */
    <?php endif; ?>

    /* Wipe from Left */
    <?php if ($transition === 4): ?>
    left: 100%; /* Move out to the right */
    transition: none;
    <?php endif; ?>

    /* Wipe from Top */
    <?php if ($transition === 5): ?>
    top: 100%; /* Move out downward */
    transition: none;
    <?php endif; ?>

    /* Wipe from Bottom */
    <?php if ($transition === 6): ?>
    top: -100%; /* Move out upward */
    transition: none;
    <?php endif; ?>
  }




</style>


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>





</head>
<body>
  <div class="slideshow-container" id="slideshow"></div>

  <script>
let images = []; // Array to hold image paths
let currentIndex = 0;
let slideshowInterval; // Reference to the interval

// Function to fetch images dynamically from get_images.php
async function fetchImages() {
  try {
    const response = await fetch('get_images.php');
    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }
    const newImages = await response.json();
    if (JSON.stringify(images) !== JSON.stringify(newImages)) {
      images = newImages; // Update the image list only if it has changed
      startSlideshow();  // Restart the slideshow with the new images
    }
  } catch (error) {
    console.error("Error fetching images:", error);
  }
}

// Function to display images in the slideshow
function startSlideshow() {
  const slideshowContainer = document.getElementById('slideshow');
  slideshowContainer.innerHTML = ''; // Clear previous images

  // Create img elements for each image
  images.forEach((imagePath) => {
    const img = document.createElement('img');
    img.src = `slideshow/${imagePath}`;
    slideshowContainer.appendChild(img);
  });

  const imgElements = slideshowContainer.querySelectorAll('img');
  if (imgElements.length > 0) {
    currentIndex = 0; // Reset to the first image
    imgElements[currentIndex].classList.add('visible'); // Show the first image

    // Change images at the specified interval
    clearInterval(slideshowInterval); // Clear any existing interval
	
    slideshowInterval = setInterval(() => {
      imgElements[currentIndex].classList.remove('visible');
      currentIndex = (currentIndex + 1) % imgElements.length;
      imgElements[currentIndex].classList.add('visible');
    }, <?= $delay; ?>); // Use PHP to inject the delay

    // Fetch new images after the full slideshow cycle (after all images are shown)
    setTimeout(() => {
      fetchImages(); // Fetch new images after the full cycle completes
    }, images.length * <?= $delay; ?>); // Delay based on number of images and the delay time
  } else {
    slideshowContainer.innerHTML = "<p style='color:white;text-align:center;'>No images available.</p>";
  }
}

// Fetch images and start the slideshow on page load
fetchImages();




		
					// Periodically refresh images to handle changes (e.g., deletions)
					// not sure if i need this below line
					//setInterval(fetchImages, 120000); // Refresh every 120 seconds
					
					
					 // Periodically check for image deletions based on the schedule
						setInterval(function() {
						  fetchDeletionSchedule();  // Call the function to check for file deletions
						}, 60000);  // 1800000 = 30 min, 21600000 = 6 hours. 43200000 Refresh every 12 hours (12 hours * 60 minutes * 60 seconds = 43200 seconds)
					
						// Function to fetch the deletion schedule from the server
						function fetchDeletionSchedule() {
						  $.ajax({
							url: 'deleteFiles.php',  // PHP file that checks and deletes files based on the schedule
							type: 'GET',
							success: function(response) {
							  console.log("Deletion check completed:", response);
							},
							error: function(xhr, status, error) {
							  console.error("Error in deletion check:", status, error);
							}
						  });
						}
			


  </script>
</body>
</html>
