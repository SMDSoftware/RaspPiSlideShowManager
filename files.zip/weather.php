<?php
$lat = "26.7017"; // Latitude for ZIP 33411
$lon = "-80.1948"; // Longitude for ZIP 33411
$url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code";
        
$weatherResponse = @file_get_contents($url); // @ to suppress warnings
if ($weatherResponse === false) {
    echo ""; // Empty string when offline - JS will show only time
} else {
    $data = json_decode($weatherResponse, true);
    if ($data === null || !isset($data['current'])) {
        echo ""; // Empty string if JSON fails
    } else {
        $temp = isset($data['current']['temperature_2m']) ? $data['current']['temperature_2m'] : "N/A";
        $weatherCode = isset($data['current']['weather_code']) ? $data['current']['weather_code'] : 0;
        switch ($weatherCode) {
            case 0: $desc = "Clear"; break;
            case 1: $desc = "Mainly Clear"; break;
            case 2: $desc = "Partly Cloudy"; break;
            case 3: $desc = "Overcast"; break;
            case 45: $desc = "Fog"; break;
            case 48: $desc = "Rime Fog"; break;
            case 51: $desc = "Light Drizzle"; break;
            case 53: $desc = "Drizzle"; break;
            case 55: $desc = "Heavy Drizzle"; break;
            case 56: $desc = "Light Freezing Drizzle"; break;
            case 57: $desc = "Heavy Freezing Drizzle"; break;
            case 61: $desc = "Light Rain"; break;
            case 63: $desc = "Rain"; break;
            case 65: $desc = "Heavy Rain"; break;
            case 66: $desc = "Light Freezing Rain"; break;
            case 67: $desc = "Heavy Freezing Rain"; break;
            case 71: $desc = "Light Snow"; break;
            case 73: $desc = "Snow"; break;
            case 75: $desc = "Heavy Snow"; break;
            case 77: $desc = "Snow Grains"; break;
            case 80: $desc = "Light Showers"; break;
            case 81: $desc = "Showers"; break;
            case 82: $desc = "Heavy Showers"; break;
            case 85: $desc = "Light Snow Showers"; break;
            case 86: $desc = "Heavy Snow Showers"; break;
            case 95: $desc = "Thunderstorm"; break;
            case 96: $desc = "Thunderstorm w/ Light Hail"; break;
            case 99: $desc = "Thunderstorm w/ Heavy Hail"; break;
            default: $desc = "Unknown"; break;
        }
        echo round($temp * 9/5 + 32) . "°F, $desc";
    }
}
?>