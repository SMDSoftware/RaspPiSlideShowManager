<?php
// Debugging setup
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);

// Define the password
$password = "wrmc33414"; // Replace with your desired password

// Start session with updated configuration
session_set_cookie_params([
    'lifetime' => 3600, // 1 hour
    'path' => '/',
    'domain' => '',
    'secure' => false,
    'httponly' => true,
    'samesite' => 'Lax'
]);
session_start();

$_SESSION['access_granted'] = true; // need this for pages like view_images.php and edit_schedule.php

// Generate a CSRF token and store it in the session
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); // Generate a random 32-byte token
}
// done with Generate a CSRF token and store it in the session



// If a password is posted, check it
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['password'])) {
    if ($_POST['password'] === $password) {
        // Set session variables for authentication and timestamp
        $_SESSION['authenticated'] = true;
        $_SESSION['authenticated_at'] = time();
    } else {
        $error = "Login failed. Try again.";
    }
}

// Check session expiration (1 hour)
if (isset($_SESSION['authenticated_at']) && (time() - $_SESSION['authenticated_at']) > 3600) {
    // Unset authentication if session is expired
    unset($_SESSION['authenticated']);
    unset($_SESSION['authenticated_at']);
}

// Show the login form if the user is not authenticated
if (!isset($_SESSION['authenticated'])):
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - ShowCase</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <style>
        body { background-color: #121212; color: white; }
        .card { background-color: #1e1e1e; }
        .card-title { background-color: #1e1e1e; color: white; }
        .card-body { color: white; }
        .btn-dark { background-color: #333; border-color: #444; }
        .alert { margin-top: 10px; }
        img { max-width: 100%; height: auto; }
    </style>
    
<meta http-equiv="Content-Security-Policy" content="
    default-src 'self'; 
    script-src 'self' https://cdn.jsdelivr.net 'nonce-random123'; 
    style-src 'self' https://cdn.jsdelivr.net 'unsafe-inline'; 
    img-src 'self' data:; 
    object-src 'none'; 
    base-uri 'self'; 
    form-action 'self'; 
    frame-ancestors 'none';
">


</head>
<body>
<div class="container d-flex justify-content-center align-items-center vh-100" style="background-color: #121212; color: white;">
    <div class="card p-4" style="max-width: 400px; width: 100%; background-color: #1e1e1e; color: white;">
        <h1 class="text-center mb-4">Login</h1>
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div>
        <?php endif; ?>
        <form method="post">
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" name="password" id="password" class="form-control" style="background-color: black; color: white; border: 1px solid #444;" required autofocus>
            </div>
            <button type="submit" class="btn btn-primary w-100"><strong>Login</strong></button>
        </form>
    </div>
</div>


<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js"></script>
</body>
</html>
<?php
exit; // Stop further execution if not authenticated
endif;

// Handle image upload


$target_dir = __DIR__ . '/slideshow/';
$scheduleFile = __DIR__ . '/deletion_schedule.txt';



// get resolution max and warning from text file resolution.txt
$warning_width = $warning_height = $blocked_width = $blocked_height = "";


// Path to the resolution.txt file
$resolutionFile = __DIR__ . '/resolution.txt';

// Check if the file exists and read values
if (file_exists($resolutionFile)) {
    $lines = file($resolutionFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        list($key, $value) = explode("=", $line);
        switch ($key) {
            case "WarningWidth":
                $warning_width = htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
                break;
            case "WarningHeight":
                $warning_height = htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
                break;
            case "BlockWidth":
                $blocked_width = htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
                break;
            case "BlockHeight":
                $blocked_height = htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
                break;
        }
    }
}
// done with resolution max




$width = $height = 0; // need defaults

if (isset($_POST['upload'])) {
    // Ensure the slideshow folder exists
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    // Sanitize the original file name to prevent directory traversal
    $file_name = basename($_FILES["imageToUpload"]["name"]);
    $safe_file_name = preg_replace('/[^\w\._-]/', '_', $file_name); // Replace unsafe characters with underscores

    $target_file = $target_dir . $safe_file_name;
	
	
    $uploadOk = 1;

    // Validate file as an image using MIME type
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime_type = finfo_file($finfo, $_FILES["imageToUpload"]["tmp_name"]);
    finfo_close($finfo);

    if (!in_array($mime_type, ['image/jpeg', 'image/png', 'image/gif'])) {
        $uploadOk = 0;
		$ErrorText = "The file you uploaded is not a recognized image format. Please upload a valid image file (e.g., JPG, PNG, GIF).";
    }

// Check file size (limit to 10MB)
if ($_FILES["imageToUpload"]["size"] > 10 * 1024 * 1024) { // 10MB in bytes
    $ErrorText = "The file you uploaded is too large. Please upload an image that is 10MB or smaller.";
    $uploadOk = 0;
}





// Check image resolution (warn or block)
$image_info = getimagesize($_FILES["imageToUpload"]["tmp_name"]);
$showModal = false; // Flag for warning modal
$blockModal = false; // Flag for blocking modal

if ($image_info !== false) {
    list($width, $height) = $image_info;




    $max_width = $warning_width;  // Warning threshold
    $max_height = $warning_height;  // Warning threshold
	
					

					
					$elements = explode(",", trim(file_get_contents('resolution.txt'))); 
					
					$max_width = isset($elements[0]) ? htmlspecialchars(trim($elements[0]), ENT_QUOTES, 'UTF-8') : "N/A";
					$max_height = isset($elements[1]) ? htmlspecialchars(trim($elements[1]), ENT_QUOTES, 'UTF-8') : "N/A";
					$block_width = isset($elements[2]) ? htmlspecialchars(trim($elements[2]), ENT_QUOTES, 'UTF-8') : "N/A"; 
                    $block_height = isset($elements[3]) ? htmlspecialchars(trim($elements[3]), ENT_QUOTES, 'UTF-8') : "N/A"; 

					
					
                
   // $block_width = $blocked_width; //4000; // Hard limit
    //$block_height = $blocked_height; //4000; // Hard limit

$elements = explode(",", file_get_contents('resolution.txt')); 
    // Check if image exceeds the absolute block limit
    if ($width > $block_width || $height > $block_height) {
        $blockModal = true; // Trigger blocking modal
		$uploadOk = 0;
		$ErrorText = "Your image size of {$width} x {$height} exceeds the upload limit and cannot be uploaded.";
    } elseif ($width > $max_width || $height > $max_height) {
        $showModal = true; // Trigger warning modal
    }
}

// Output the blocking modal if image is too large
?>
<div class='modal fade' id='resolutionBlockModal' tabindex='-1' aria-labelledby='resolutionBlockLabel' aria-hidden='true' data-bs-backdrop="static" data-bs-keyboard="false">
    <div class='modal-dialog modal-dialog-centered'>
        <div class='modal-content'>
            <div class='modal-header bg-danger text-white'>
                <h5 class='modal-title' id='resolutionBlockLabel'>Image Upload Blocked</h5>
            </div>
            <div class='modal-body text-black'>
                <p>Your image resolution is <strong><?= $width ?> x <?= $height ?></strong>, which exceeds the maximum allowed size of 
                
                <strong>
                
				<?php 
                    echo $block_width;
                ?>

                X
                
				<?php 
                    echo $block_height;
                ?>                
                
                </strong>.
                
                
                </p>
                <ul>
                    <?php if ($width > $block_width) echo "<li><strong>Width too large:</strong> Max {$block_width}, Yours: {$width}</li>"; ?>
                    <?php if ($height > $block_height) echo "<li><strong>Height too large:</strong> Max {$block_height}, Yours: {$height}</li>"; ?>
                </ul>
                <p>Please significantly reduce your image size before uploading.</p>
            </div>
            <div class='modal-footer'>
                <button type='button' class='btn btn-danger' onclick="resetUpload()">OK</button>
            </div>
        </div>
    </div>
</div>

<?php
// Output the warning modal if image is large but allowed
?>
<div class='modal fade' id='resolutionWarningModal' tabindex='-1' aria-labelledby='resolutionWarningLabel' aria-hidden='true' data-bs-backdrop="static" data-bs-keyboard="false">
    <div class='modal-dialog modal-dialog-centered'>
        <div class='modal-content'>
            <div class='modal-header bg-warning text-dark'>
                <h5 class='modal-title' id='resolutionWarningLabel'>Image Resolution Warning</h5>
            </div>
            <div class='modal-body text-black'>
              <p>Your image resolution is <strong><?= $width ?> x <?= $height ?></strong>, which exceeds the recommended maximum of 
              
                <strong>
				<?php 
                    echo $max_width;
                ?>

                X
                
				<?php 
                    echo $max_height;
                ?>               
                
                </strong>.
              
              
              </p>
                <ul>
                    <?php if ($width > $max_width) echo "<li><strong>Width too large:</strong> Max {$max_width}, Yours: {$width}</li>"; ?>
                    <?php if ($height > $max_height) echo "<li><strong>Height too large:</strong> Max {$max_height}, Yours: {$height}</li>"; ?>
                </ul>
                <p><strong>What this means:</strong> Parts of the image may get cut off in the slideshow.</p>
                <p>You can still upload this image, but it may not display correctly.</p>
            </div>
            <div class='modal-footer'>
                <button type='button' class='btn btn-dark' data-bs-dismiss='modal'>OK</button>
            </div>
        </div>
    </div>
</div>

<script nonce="random123">
    document.addEventListener("DOMContentLoaded", function() {
        <?php if ($blockModal) { ?>
            var blockModal = new bootstrap.Modal(document.getElementById('resolutionBlockModal'));
            blockModal.show();
            document.getElementById("uploadButton").disabled = true; // Disable upload button
        <?php } elseif ($showModal) { ?>
            var warningModal = new bootstrap.Modal(document.getElementById('resolutionWarningModal'));
            warningModal.show();
        <?php } ?>
    });

function resetUpload() {
    var fileInput = document.getElementById("imageToUpload");
    var uploadBtn = document.getElementById("uploadButton");

    if (fileInput) fileInput.value = ""; // Clear file input
    if (uploadBtn) uploadBtn.disabled = false; // Enable upload button again

    var blockModal = bootstrap.Modal.getInstance(document.getElementById('resolutionBlockModal'));
    if (blockModal) blockModal.hide(); // Hide modal after resetting
}
</script>


<?php
// Done with resolution testing
?>







<?php

    // Allow certain file formats
    $file_extension = strtolower(pathinfo($safe_file_name, PATHINFO_EXTENSION));
    if (!in_array($file_extension, ["jpg", "jpeg", "png", "gif"])) {
        $uploadOk = 0;
		$ErrorText = "The file you uploaded is not a recognized image format. Please upload a valid image file (e.g., JPG, PNG, GIF).";
    }

    // Check if everything is ok to upload
    if ($uploadOk == 0) {
        $UploadconfirmationMessage = $ErrorText;
    } else {
        if (move_uploaded_file($_FILES["imageToUpload"]["tmp_name"], $target_file)) {
            $UploadconfirmationMessage = "The file has been uploaded successfully as: $safe_file_name.";

            // Check if a deletion date is set
            if (!empty($_POST["deletionDate"])) {
                $deleteDate = $_POST["deletionDate"];

                // Validate the date format (YYYY-MM-DD)
                if (preg_match("/^\d{4}-\d{2}-\d{2}$/", $deleteDate)) {
                    // Correct entry format: file first, then delete date
                    $entry = "$safe_file_name|$deleteDate\n";
                    
                    // Attempt to write the entry and check if it's successful
                    $writeResult = file_put_contents($scheduleFile, $entry, FILE_APPEND);

                    if ($writeResult === false) {
                        $UploadconfirmationMessage .= " Error: Could not write to deletion schedule.";
                    } else {
                        $UploadconfirmationMessage .= " Deletion date scheduled for: $deleteDate.";
                    }
                } else {
                    $UploadconfirmationMessage .= " Invalid date format.";
                }
            }
        } else {
            $UploadconfirmationMessage = "Sorry, there was an error uploading your file.";
        }
    }
} // this might be the closing of "if (isset($_POST['upload'])) {"

// Allow certain file formats


// Handle image deletion

if (isset($_GET['delete'])) {
    $imageName = basename($_GET['delete']); // Sanitize to prevent directory traversal
    $target_dir = __DIR__ . '/slideshow/';  // Set the target directory where images are stored
    $file = $target_dir . $imageName; // Full file path

		if (file_exists($file)) {
			if (unlink($file)) {
				echo "<div class='alert alert-success'>The file has been deleted successfully.</div>";
				
				// Use JavaScript to clear the URL query string
				echo "<script>
					history.pushState(null, null, window.location.pathname);
				</script>";
			} else {
				echo "<div class='alert alert-danger'>There was an error deleting the file.</div>";
			}
		} else {
			echo "<div class='alert alert-danger'>File not found.</div>";
		}

}
// done with image deletion


// Handle delay setting with CSRF protection
if (isset($_POST['delay'])) {
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die('Invalid CSRF token');
    }

    // Get the delay value
    $delay = max(1, min(999, (int)$_POST['delay']));

    // Save the delay to a file
    file_put_contents('delay.txt', $delay);

    // Success message
    $confirmationMessage = "Slideshow delay updated to: $delay seconds.";
}

// Get the saved delay value (default to 6 seconds if not set)
$delay = file_exists('delay.txt') ? file_get_contents('delay.txt') : 6;  // Default to 6 seconds if not set

// Done with delay setting



// Handle location setting
if (isset($_POST['location'])) {
    
    // Check CSRF token validity
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        // Handle CSRF token failure
        $locationConfirmationMessage = "Invalid Location CSRF token."; // Error message
        die($locationConfirmationMessage);  // Stop execution and show the message
    } else {
        // Sanitize the location input to prevent malicious input
        $location = htmlspecialchars(trim($_POST['location']), ENT_QUOTES, 'UTF-8');
        
        // Limit the length of location to 25 characters
        $location = substr($location, 0, 25);

        // Ensure the location is alphanumeric and allows only a limited set of special characters (e.g., space and hyphen)
		if (preg_match('/^[a-zA-Z0-9\s\-.]+$/', $location)) {
            // Save the location to a file
            file_put_contents('location.txt', $location); 
            
            // Success message
            $locationConfirmationMessage = "Location updated to: $location."; 
        } else {
            // Error message if the location contains invalid characters
            $locationConfirmationMessage = "Invalid characters in location. Only letters, numbers, spaces, and hyphens are allowed."; 
        }
    }
}

// Get the saved location value (default to 'Unknown' if not set)
$locationFile = 'location.txt';
$location = file_exists($locationFile) ? file_get_contents($locationFile) : 'Unknown';

// done with location


// Handle overlay setting
if (isset($_POST['overlay'])) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $overlayConfirmationMessage = "Invalid Overlay CSRF token.";
        die($overlayConfirmationMessage);
    } else {
        $overlay = (int)$_POST['overlay']; // Cast to integer
        // Validate: must be 0, 1, 2, or 3
        if ($overlay >= 0 && $overlay <= 3) {
            file_put_contents('overlay.txt', $overlay);
            $overlayOptions = ["Off", "Weather and Time", "Weather Only", "Time Only"];
            $overlayConfirmationMessage = "Overlay setting updated to: " . $overlayOptions[$overlay] . ".";
        } else {
            $overlayConfirmationMessage = "Invalid overlay option selected.";
        }
    }
}

// Get the saved overlay value (default to 0 if not set)
$overlayFile = 'overlay.txt';
$selectedOverlay = file_exists($overlayFile) ? (int)trim(file_get_contents($overlayFile)) : 0;

// Done with location and overlay






// Handle transition setting
// Map transition numbers to their names
$transitionNames = [
    1 => 'Normal (No Transition)',
    2 => 'Fade',
	3 => 'Wipe from right',
	4 => 'Wipe from Left',
	5 => 'Wipe from Top',
	6 => 'Wipe from Bottom'

];

// Handle transition setting with CSRF protection
if (isset($_POST['transition'])) {
    // Validate CSRF token
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
		$transitionConfirmationMessage = "Invalid Transition CSRF token.";
        die('Invalid CSRF token');
    }

    // Get the selected transition value
    $transition = (int) $_POST['transition'];

    // Validate the transition value (allow only 1 or 2)
    if (in_array($transition, [1, 2, 3, 4, 5, 6], true)) {
        file_put_contents('transitions.txt', $transition); // Save the transition type to a file
        $transitionName = isset($transitionNames[$transition]) ? $transitionNames[$transition] : 'Unknown'; // Get the transition name or 'Unknown' if not found
        $transitionConfirmationMessage = "Transition updated to: $transitionName."; // Success message
    } else {
        $transitionConfirmationMessage = "Error: Invalid transition. Please choose from 'Normal', 'Fade', or 'Wipe'.";
    }
}

// Get the saved transition value (default to 2: Crossfade if not set)
$transitionsFile = 'transitions.txt';
$selectedTransition = file_exists($transitionsFile) ? (int) file_get_contents($transitionsFile) : 2;

// Done with transition setting




// Get all images in the slideshow directory
$image_dir = __DIR__ . '/slideshow/';
$images = glob($image_dir . '*.{jpg,jpeg,png,gif,JPG,JPEG,PNG,GIF}', GLOB_BRACE);
// done with getting all images in the slideshow directory



// Handle resolution setting
if (
    isset($_POST['warning_width'], $_POST['warning_height'], $_POST['blocked_width'], $_POST['blocked_height'])
) {
    // Check CSRF token validity
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $resolutionConfirmationMessage = "Invalid CSRF token.";
        die($resolutionConfirmationMessage);
    } else {
        // Sanitize and validate resolution inputs
        $warning_width = max(1, intval($_POST['warning_width']));
        $warning_height = max(1, intval($_POST['warning_height']));
        $blocked_width = max(1, intval($_POST['blocked_width']));
        $blocked_height = max(1, intval($_POST['blocked_height']));

        // Create the resolution string
        $resolutionData = "$warning_width,$warning_height,$blocked_width,$blocked_height";

        // Save to resolution.txt
        file_put_contents('resolution.txt', $resolutionData);

        // Success message
        $resolutionConfirmationMessage = "Resolution limit settings updated.";
    }
}

// Retrieve resolution settings from file
$resolutionFile = 'resolution.txt';
if (file_exists($resolutionFile)) {
    $resolutionData = file_get_contents($resolutionFile);
    $resolutionParts = explode(',', $resolutionData);
    $warning_width = isset($resolutionParts[0]) ? intval($resolutionParts[0]) : 1920;
    $warning_height = isset($resolutionParts[1]) ? intval($resolutionParts[1]) : 1080;
    $blocked_width = isset($resolutionParts[2]) ? intval($resolutionParts[2]) : 3840;
    $blocked_height = isset($resolutionParts[3]) ? intval($resolutionParts[3]) : 2160;
} else {
    // Default values
    $warning_width = 1920;
    $warning_height = 1080;
    $blocked_width = 3840;
    $blocked_height = 2160;
}

// Done with resolution handling








// Fetch the current hostname
$currentHostname = trim(shell_exec("cat /etc/hostname"));

// Check if this is a hostname update form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['form_type']) && $_POST['form_type'] === "hostname_update") {
    if (isset($_POST['csrf_token']) && $_POST['csrf_token'] === $_SESSION['csrf_token']) {
        $new_hostname = preg_replace("/[^a-zA-Z0-9\-]/", "", $_POST['hostname']); // Sanitize input

        if (!empty($new_hostname)) {
            $currentHostname = trim(shell_exec("hostname"));

            if ($currentHostname !== $new_hostname) {
                // Update hostname
                shell_exec("echo '$new_hostname' | sudo tee /etc/hostname");
                shell_exec("sudo sed -i 's/^127\\.0\\.1\\.1.*/127.0.1.1 $new_hostname/' /etc/hosts");
                shell_exec("sudo hostname $new_hostname");

                // Reboot to apply changes
               // shell_exec("sudo reboot");

                // Confirmation message
                $hostnameConfirmationMessage = "Hostname updated to '" . htmlspecialchars($new_hostname) . "'. Reboot Display Now...";
				
				    echo "
						<script type='text/javascript'>
							document.addEventListener('DOMContentLoaded', function() {
								var rebootModal = new bootstrap.Modal(document.getElementById('rebootModal'));
								rebootModal.show();
							});
						</script>
					";
	
            } else {
                $hostnameConfirmationMessage = "Hostname is already set to " . htmlspecialchars($new_hostname) . ". No changes made.";
            }
        } else {
            $hostnameConfirmationMessage = "Invalid hostname!";
        }
    }
}

// end if current hostname changing






       
        // Check if the user want to reset chromium
        if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['reinstall_x11']) && $_POST['reinstall_x11'] === "true") {
            // Execute the shell commands to reinstall X11 and reset Chromium settings
 // Turn off output buffering and flush previous output
 echo "<pre>Please Wait... Then Reboot</pre>";
    ob_end_flush(); // you need needs two or the code wont run right
    flush();


    // Execute shell commands
$output1 = shell_exec("sudo apt-get install --reinstall --no-install-recommends xserver-xorg x11-xserver-utils xinit openbox 2>&1");
$output2 = shell_exec("sudo rm -rf /home/pi/.config/chromium/ 2>&1");



//echo "<pre>Command 1 Output:\n$output1</pre>";
//echo "<pre>Command 2 Output:\n$output2</pre>";

	    // Output JavaScript to trigger the modal
   echo "
        <script type='text/javascript'>
            document.addEventListener('DOMContentLoaded', function() {
                var rebootModal = new bootstrap.Modal(document.getElementById('rebootModal'));
                rebootModal.show();
            });
        </script>
    ";
	

      
        }
        
		// done with Check if the user want to reset chromium


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="favicon.ico">
    <title>ShowCase - Image Manager</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    
<style>
body { background-color: #121212; color: white; }
.card { background-color: #1e1e1e; }
.card-title { background-color: #1e1e1e; color: white; }
.card-body { color: white; }
.btn-dark { background-color: #333; border-color: #444; }
.alert { margin-top: 10px; }
img { max-width: 100%; height: auto; }

        /* Tab customizations for dark theme */
        .nav-tabs { border-bottom: 1px solid #444; }
        .nav-tabs .nav-link { color: #bbb; background-color: #1e1e1e; border: 1px solid #444; border-bottom: none; }
        .nav-tabs .nav-link:hover { color: white; border-color: #666; }
        .nav-tabs .nav-link.active { color: white; background-color: #333; border: 1px solid #444; border-bottom: 1px solid #333; }
        .tab-content { background-color: #121212; padding: 20px; }
		
</style>





</head>
<body>

<div class="container mt-4">
    <h1 class="text-center">ShowCase v. 1.0.7</h1>
    <h2 class="text-center" title="Current Location of this device"><?php echo htmlspecialchars($location, ENT_QUOTES, 'UTF-8'); ?></h2>
    
    

   
<div class="text-center mb-4 mt-4">
    <div class="d-flex justify-content-center gap-2">
        <a href="view_images.php" class="btn btn-primary" style="width: 150px;"><strong>View Images</strong></a>
        <a href="slideshow.php" target="_blank" class="btn btn-primary" style="width: 150px;"><strong>View Slideshow</strong></a>
    </div>
</div>



<!-- start of tabs -->

<!-- start of tabs headers-->
    <div class="container mt-4">
        <!-- Bootstrap Tabs -->
        <ul class="nav nav-tabs" id="myTab" role="tablist">
            <!-- Images Tab (Default, Leftmost) -->
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="images-tab" data-bs-toggle="tab" data-bs-target="#images" type="button" role="tab" aria-controls="images" aria-selected="true"><strong>Images</strong></button>
            </li>
            
            <!-- Settings Tab -->
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="settings-tab" data-bs-toggle="tab" data-bs-target="#settings" type="button" role="tab" aria-controls="settings" aria-selected="false"><strong>Settings</strong></button>
            </li>
            
            <!-- Device Tab -->
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="device-tab" data-bs-toggle="tab" data-bs-target="#device" type="button" role="tab" aria-controls="device" aria-selected="false"><strong>Device</strong></button>
            </li>
        </ul>
<!-- end of tabs headers-->


        <div class="tab-content" id="myTabContent">
            <!-- Images Tab Content -->
            <div class="tab-pane fade show active" id="images" role="tabpanel" aria-labelledby="images-tab">
                <!-- Move your Images content here -->
                
<!-- Image Upload Form -->
    <div class="card mb-4">
        <div class="card-body">
            <h3 class="card-title"><strong>Upload New Image</strong></h3>
                <form method="post" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label for="imageToUpload" class="form-label">Select image to upload:</label>
                        <input type="file" name="imageToUpload" id="imageToUpload" class="form-control" required>
                    </div>
                
                    <!-- Checkbox for Scheduling Deletion -->
                    <div class="mb-3">
                        <input type="checkbox" id="scheduleDeletion" name="scheduleDeletion" title="Select this option only to specify a date for automatic image deletion.">
                        <label for="scheduleDeletion">Schedule for Deletion</label>
                    </div>
                
                    <!-- Date Picker (Hidden by Default) -->
                    <div class="mb-3" id="datePickerContainer" style="display: none;">
                        <label for="deletionDate" class="form-label">Select Deletion Date:</label>
                        <input type="date" id="deletionDate" name="deletionDate" class="form-control">
                    </div>
                
                    <button type="submit" name="upload" id="uploadButton" class="btn btn-primary"><strong>Upload</strong></button>
                </form>
                
                <script nonce="random123">
                    document.getElementById("scheduleDeletion").addEventListener("change", function () {
                        document.getElementById("datePickerContainer").style.display = this.checked ? "block" : "none";
                    });
                </script>


            
                    <!-- Display Confirmation Message -->
        <?php if (isset($UploadconfirmationMessage)): ?>
            <div class="alert alert-success mt-3" role="alert">
                <?php echo htmlspecialchars($UploadconfirmationMessage, ENT_QUOTES, 'UTF-8'); ?>
            </div>
        <?php endif; ?>
        
        </div>
    </div>
<!-- end of Image Upload Form -->
    
    
<!-- Edit Deletion Schedule -->
<div class="card mb-4">
    <div class="card-body">
        <h3 class="card-title"><strong>Edit Deletion Schedule</strong></h3>
        <p>Manage the scheduled deletions by editing the schedule file</p>
        <a href="edit_schedule.php" class="btn btn-primary" title="Edit the deletion schedule">
            <strong>Edit Schedule</strong>
        </a>
    </div>
</div>
<!-- end of Edit Deletion Schedule -->    


<!-- Display Uploaded Images -->
<div class="row">
    <?php foreach ($images as $index => $image): ?>
        <?php $imageName = basename($image); ?>
            <div class="col-md-4">
                <div class="card mb-4">
                   <a href="#" data-bs-toggle="modal" data-bs-target="#imageModal<?php echo $index; ?>" title="<?php echo htmlspecialchars($imageName, ENT_QUOTES, 'UTF-8'); ?>">
                        <img src="slideshow/<?php echo htmlspecialchars($imageName, ENT_QUOTES, 'UTF-8'); ?>" class="card-img-top" alt="Image">
                    </a>
<div class="card-body text-center">
    <!-- Delete Button - Triggers the Modal -->
    <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#deleteModal" data-image="<?php echo urlencode($imageName); ?>">
        <strong>Delete</strong>
    </button>

    <!-- Download Button -->
    <a href="slideshow/<?php echo htmlspecialchars($imageName, ENT_QUOTES, 'UTF-8'); ?>" 
       class="btn btn-primary" 
       title="Click to download this image" 
       download="<?php echo htmlspecialchars($imageName, ENT_QUOTES, 'UTF-8'); ?>">
       <strong>Download</strong>
    </a>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-black" id="deleteModalLabel"><strong>Confirm Deletion</strong></h5>
            </div>
            <div class="modal-body text-black">
                <p>Are you sure you want to delete this image?</p>
                <p><strong id="imageToDelete"></strong></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><strong>Cancel</strong></button>
                <a id="confirmDelete" href="#" class="btn btn-danger"><strong>Delete</strong></a>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript to Set Image Name in Modal -->
<script>
    document.querySelectorAll('[data-bs-target="#deleteModal"]').forEach(button => {
        button.addEventListener('click', function () {
            let imageName = this.getAttribute('data-image');
            document.getElementById('imageToDelete').textContent = imageName;
            document.getElementById('confirmDelete').href = "?delete=" + imageName;
        });
    });
</script>

                </div>
            </div>


        <!-- Modal for viewing image larger -->
        <?php
			$imagePath = "slideshow/" . $imageName;
			$imageInfo = getimagesize($imagePath);
			$imageWidth = $imageInfo[0];  // Width of the image
			$imageHeight = $imageInfo[1]; // Height of the image
		?>

        <div class="modal fade" id="imageModal<?php echo $index; ?>" tabindex="-1" aria-labelledby="imageModalLabel<?php echo $index; ?>" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="imageModalLabel<?php echo $index; ?>" style="color: black;">
                            <?php echo htmlspecialchars($imageName, ENT_QUOTES, 'UTF-8'); ?>
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <img src="slideshow/<?php echo $imageName; ?>" class="img-fluid" alt="Larger View">
                        <p class="mt-2 text-muted">Resolution: <?php echo $imageWidth . " x " . $imageHeight; ?></p>
                    </div>
                </div>
            </div>
        </div>

        
    <?php endforeach; ?>
</div>

<!-- done with Display Uploaded Images -->

    
            </div>

            <!-- Settings Tab Content -->
            <div class="tab-pane fade" id="settings" role="tabpanel" aria-labelledby="settings-tab">
                <!-- Move your Settings content here (e.g., Delay, Transition, Overlay forms) -->
                
<!-- Slideshow Delay Form -->
<div class="card mb-4">
    <div class="card-body">
        <h3 class="card-title"><strong>Set Slideshow Delay</strong></h3>
        <form action="index.php" method="post">
          <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            <div class="mb-3">
<label for="delay" class="form-label">
    Slideshow Delay (seconds) – A reboot is required after changes, especially when switching to a single image, as transitions will be disabled.
</label>
                <input type="number" name="delay" id="delay" class="form-control" value="<?php echo htmlspecialchars($delay, ENT_QUOTES, 'UTF-8'); ?>" min="1" max="999" required>
            </div>
            <button type="submit" class="btn btn-primary" title="Click to save delay"><strong>Save Delay</strong></button>
        </form>

        <!-- Display Confirmation Message -->
        <?php if (isset($confirmationMessage)): ?>
            <div class="alert alert-success mt-3" role="alert">
                <?php echo htmlspecialchars($confirmationMessage, ENT_QUOTES, 'UTF-8'); ?>
            </div>
        <?php endif; ?>
    </div>
</div>
<!-- end of Slideshow Delay Form -->


<!-- Set Location Form -->
<div class="card mb-4">
    <div class="card-body">
        <h3 class="card-title"><strong>Set Device Location</strong></h3>
        <form action="index.php" method="post">
        	<input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            <div class="mb-3">
                <label for="location" class="form-label">Location of this display system</label>
                <input type="text" name="location" id="location" class="form-control" value="<?php echo htmlspecialchars($location); ?>" required maxlength="40" autocomplete="off" >

            </div>
            <button type="submit" class="btn btn-primary" title="Click to save location"><strong>Save Location</strong></button>
        </form>

        <!-- Display Confirmation Message -->
        <?php if (isset($locationConfirmationMessage)): ?>
            <div class="alert alert-success mt-3" role="alert">
                <?php echo htmlspecialchars($locationConfirmationMessage, ENT_QUOTES, 'UTF-8'); ?>
            </div>
        <?php endif; ?>
    </div>
</div>
<!-- end of Set Location Form -->


<!-- Set Transition Form -->
<div class="card mb-4">
    <div class="card-body">
        <h3 class="card-title"><strong>Set Slideshow Transition</strong></h3>
        <form action="index.php" method="post">
        	<input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            <div class="mb-3">
                <label for="transition" class="form-label">Transition Type - Reboot After Changing This Setting</label>
                <select name="transition" id="transition" class="form-select" required>
                    <!-- Placeholder option -->
                    <option value="" <?php echo !isset($selectedTransition) ? 'selected' : ''; ?> disabled>Select a transition</option>

                    <!-- Transition options -->
            <option value="1" <?php echo isset($selectedTransition) && $selectedTransition == 1 ? 'selected' : ''; ?>>Normal (No Transition)</option>
            <option value="2" <?php echo isset($selectedTransition) && $selectedTransition == 2 ? 'selected' : ''; ?>>Fade</option>
            <option value="3" <?php echo isset($selectedTransition) && $selectedTransition == 3 ? 'selected' : ''; ?>>Wipe from Right</option>
            <option value="4" <?php echo isset($selectedTransition) && $selectedTransition == 4 ? 'selected' : ''; ?>>Wipe from Left</option>
            <option value="5" <?php echo isset($selectedTransition) && $selectedTransition == 5 ? 'selected' : ''; ?>>Wipe from Top</option>
            <option value="6" <?php echo isset($selectedTransition) && $selectedTransition == 6 ? 'selected' : ''; ?>>Wipe from Bottom</option>

                </select>
            </div>
            <button type="submit" class="btn btn-primary" title="Click to save transition" ><strong>Save Transition</strong></button>
        </form>

        <!-- Display Confirmation Message -->
        <?php if (isset($transitionConfirmationMessage)): ?>
            <div class="alert alert-success mt-3" role="alert">
                <?php echo htmlspecialchars($transitionConfirmationMessage, ENT_QUOTES, 'UTF-8'); ?>
            </div>
        <?php endif; ?>
    </div>
</div>
<!-- end of Set Transition Form -->



<!-- Weather and Time Options Form -->
<div class="card mb-4">
    <div class="card-body">
        <h3 class="card-title"><strong>Weather and Time Options</strong></h3>
        <form action="index.php" method="post">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            <div class="mb-3">
                <label for="overlay" class="form-label">Show Weather and Time - Reboot After Changing This Setting</label>
                <select name="overlay" id="overlay" class="form-select" required>
                    <!-- Placeholder option -->
                    <option value="" <?php echo !isset($selectedOverlay) ? 'selected' : ''; ?> disabled>Select an option</option>

                    <!-- Overlay options -->
                    <option value="0" <?php echo isset($selectedOverlay) && $selectedOverlay == 0 ? 'selected' : ''; ?>>Off</option>
                    <option value="1" <?php echo isset($selectedOverlay) && $selectedOverlay == 1 ? 'selected' : ''; ?>>Weather and Time</option>
                    <option value="2" <?php echo isset($selectedOverlay) && $selectedOverlay == 2 ? 'selected' : ''; ?>>Weather Only</option>
                    <option value="3" <?php echo isset($selectedOverlay) && $selectedOverlay == 3 ? 'selected' : ''; ?>>Time Only</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary" title="Click to save weather and time setting"><strong>Save Setting</strong></button>
        </form>

        <!-- Display Confirmation Message -->
        <?php if (isset($overlayConfirmationMessage)): ?>
            <div class="alert alert-success mt-3" role="alert">
                <?php echo htmlspecialchars($overlayConfirmationMessage, ENT_QUOTES, 'UTF-8'); ?>
            </div>
        <?php endif; ?>
    </div>
</div>
<!-- end of Weather and Time Options Form -->


<!-- Set Resolution Limits Form -->
<div class="card mb-4">
    <div class="card-body">
        <h3 class="card-title"><strong>Set Resolution Limits</strong></h3>
        <form action="index.php" method="post">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">

            <!-- Warning Resolution Section -->
            <div class="mb-4 p-3 border rounded">
                <h5 class="text-warning"><strong>Warning Resolution Limits</strong></h5>
                <div class="mb-3">
                    <label for="warning_width" class="form-label">Max Warning Width</label>
                    <input type="number" name="warning_width" id="warning_width" class="form-control" value="<?php echo $warning_width; ?>" min="1" required>

                    <label for="warning_height" class="form-label mt-2">Max Warning Height</label>
                    <input type="number" name="warning_height" id="warning_height" class="form-control" value="<?php echo $warning_height; ?>" min="1" required>
                </div>
            </div>

            <!-- Blocking Resolution Section -->
            <div class="mb-4 p-3 border rounded">
                <h5 class="text-danger"><strong>Blocking Resolution Limits</strong></h5>
                <div class="mb-3">
                    <label for="blocked_width" class="form-label">Max Block Width</label>
                    <input type="number" name="blocked_width" id="blocked_width" class="form-control" value="<?php echo $blocked_width; ?>" min="1" required>

                    <label for="blocked_height" class="form-label mt-2">Max Block Height</label>
                    <input type="number" name="blocked_height" id="blocked_height" class="form-control" value="<?php echo $blocked_height; ?>" min="1" required>
                </div>
            </div>

            <button type="submit" class="btn btn-primary" title="Click to save resolution settings"><strong>Save Resolution Settings</strong></button>
        </form>

        <!-- Display Confirmation Message -->
        <?php if (isset($resolutionConfirmationMessage)): ?>
            <div class="alert alert-success mt-3" role="alert">
                <?php echo htmlspecialchars($resolutionConfirmationMessage, ENT_QUOTES, 'UTF-8'); ?>
            </div>
        <?php endif; ?>
    </div>
</div>
<!-- end of Set Resolution Limits Form -->


            </div>

            <!-- Device Tab Content -->
            <div class="tab-pane fade" id="device" role="tabpanel" aria-labelledby="device-tab">
                <!-- Move your Device content here -->
                
 
 <!-- Set Hostname Form -->
<div class="card mb-4">
    <div class="card-body">
        <h3 class="card-title"><strong>Set Device Hostname</strong></h3>
        <form action="index.php" method="post" onsubmit="return validateHostname()">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            <input type="hidden" name="form_type" value="hostname_update"> <!-- Unique identifier -->
            <div class="mb-3">
                <label for="hostname" class="form-label">
                    Enter New Hostname (Reboot Required). You can also connect to this device via:  
                    <strong>http://<?php echo htmlspecialchars($currentHostname); ?>.local</strong>  
                    or <strong>http://<?php echo $_SERVER['SERVER_ADDR']; ?></strong>
                </label>

                <input type="text" name="hostname" id="hostname" class="form-control" 
                    value="<?php echo htmlspecialchars($currentHostname); ?>" 
                    required maxlength="30">
            </div>
            <button type="submit" class="btn btn-danger" title="Click to save hostname"><strong>Save Hostname</strong></button>
        </form>

        <!-- Display Confirmation Message -->
        <?php if (isset($hostnameConfirmationMessage)): ?>
            <div class="alert alert-success mt-3" role="alert">
                <?php echo htmlspecialchars($hostnameConfirmationMessage, ENT_QUOTES, 'UTF-8'); ?>
            </div>
        <?php endif; ?>
    </div>
</div>


<!-- Bootstrap Modal for Invalid Hostname -->
<div class="modal fade" id="hostnameModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="hostnameModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content" style="background-color: #d9534f; border: 2px solid #a93226; border-radius: 8px;">
            <div class="modal-header" style="background-color: #a93226; color: white; border-top-left-radius: 8px; border-top-right-radius: 8px;">
                <h5 class="modal-title" id="hostnameModalLabel">⚠ Invalid Hostname</h5>
            </div>
            <div class="modal-body">
                <p><strong>The hostname must meet the following requirements:</strong></p>
                <ul>
                    <li>Only lowercase letters (<strong>a-z</strong>), numbers (<strong>0-9</strong>), and hyphens (<strong>-</strong>)</li>
                    <li>Cannot start or end with a hyphen (<strong>-</strong>)</li>
                    <li>Maximum length of <strong>30 characters</strong></li>
                    <li>Must be <strong>unique</strong> on the network</li>
                </ul>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-bs-dismiss="modal"><strong>OK</strong></button>
            </div>
        </div>
    </div>
</div>






<!-- JavaScript for hostname validation and modal trigger -->
<script>
function validateHostname() {
    let hostname = document.getElementById("hostname").value;
    let regex = /^[a-z0-9]+(-[a-z0-9]+)*$/;

    if (hostname.length > 30 || !regex.test(hostname)) {
        let modal = new bootstrap.Modal(document.getElementById("hostnameModal"));
        modal.show();
        return false;
    }
    return true;
}
</script>

<!-- end of Set Hostname Form -->


<!-- Reboot Raspberry Pi -->
<div class="card mb-4">
    <div class="card-body">
        <h3 class="card-title"><strong>Reboot Slideshow Device</strong></h3>
        <p>Some settings require a reboot for changes to take effect on the ShowCase Device.</p>
    <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#rebootModal" title="Click here to reboot the display device.">
        <strong>Reboot Display</strong>
    </button>
    </div>
</div>


<!-- Reboot Confirmation Modal -->
<div class="modal fade" id="rebootModal" tabindex="-1" aria-labelledby="rebootModalLabel" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-dark" id="rebootModalLabel"><strong>Confirm Reboot</strong></h5>
            </div>
            <div class="modal-body text-dark">
                <p>A reboot is required for some changes to take effect. Are you sure you want to restart the display device now?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><strong>Cancel</strong></button>
                <form action="reboot.php" method="post">
                    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                    <button type="submit" class="btn btn-danger"><strong>Yes, Reboot</strong></button>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- end of Reboot Raspberry Pi -->



<!-- Reinstall Display Profile -->
<div class="card mb-4">
    <div class="card-body">
        <h3 class="card-title"><strong>Reset Display Settings</strong></h3>
<p>This action is required after changing the device's hostname and rebooting. Running this will reset the display settings to ensure everything functions correctly. The screen may go blank during the reset process. After this process is complete, another reboot will be required.</p>
        <!-- Button to trigger the process -->
        <form action="index.php" method="post">
            <button type="submit" name="reinstall_x11" value="true" class="btn btn-danger">
                <strong>Reset Display</strong>
            </button>
        </form>
    </div>
</div>
<!-- end of Reinstall Display Profile -->
               
                
                
            </div>
        </div>
    </div>
    
    
<!-- end of tabs -->    








    
    
    
</div>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js"></script>



</body>
</html>