<?php
// File: get_images.php

// Enable error reporting for debugging (optional)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Define the folder containing the images
$imageFolder = "slideshow";

// Scan the directory for files and remove '.' and '..'
$images = array_diff(scandir($imageFolder), array('.', '..'));

// Specify the valid image file extensions
$validImageExtensions = ['jpg', 'jpeg', 'png', 'gif'];

// Filter the images to include only files with valid extensions (case-insensitive)
$images = array_filter($images, function ($image) use ($validImageExtensions) {
    $ext = strtolower(pathinfo($image, PATHINFO_EXTENSION));
    return in_array($ext, $validImageExtensions);
});

// Set the response header to indicate JSON content
header('Content-Type: application/json');

// Return the list of images as a JSON-encoded array
echo json_encode(array_values($images));

?>
