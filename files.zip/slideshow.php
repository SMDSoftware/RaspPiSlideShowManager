<?php
// Enable error reporting for debugging (optional)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Get the delay setting from the delay.txt file (default to 6000ms if not set)
$delay = 6000; // Default value of 6000ms (6 seconds)
$delayFile = __DIR__ . '/delay.txt';  // Full path to delay.txt
if (file_exists($delayFile)) {
    $content = trim(file_get_contents($delayFile));
    $delay = is_numeric($content) ? (int)$content * 1000 : 6000;
}

// Get the transition setting from the transitions.txt file
$transition = 2; // Default value (fade)
$transitionFile = __DIR__ . '/transitions.txt'; // Full path to transitions.txt
if (file_exists($transitionFile)) {
    $content = trim(file_get_contents($transitionFile));
    $transition = is_numeric($content) ? (int)$content : 2;
    if ($transition < 2 || $transition > 6) $transition = 2; // Clamp to valid range
}


// Read overlay setting
$overlayFile = __DIR__ . '/overlay.txt';
$overlaySetting = file_exists($overlayFile) ? (int)trim(file_get_contents($overlayFile)) : 0; // Default to 0 (off)


// Weather data from Open-Meteo (ZIP 33411 - West Palm Beach, FL)
$lat = "26.7017"; // Latitude for ZIP 33411
$lon = "-80.1948"; // Longitude for ZIP 33411 - explicitly defined
$weatherUrl = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code"; // Fixed typo "current" and ensured $lon
$weatherResponse = @file_get_contents($weatherUrl); // @ to suppress warnings
if ($weatherResponse === false) {
    $weatherText = ""; // Empty string when offline - show only time
} else {
    $weatherData = json_decode($weatherResponse, true);
    if ($weatherData === null || !isset($weatherData['current'])) {
        $weatherText = ""; // Empty string if JSON fails or structure is off
    } else {
        $temp = isset($weatherData['current']['temperature_2m']) ? $weatherData['current']['temperature_2m'] : "N/A";
        $weatherCode = isset($weatherData['current']['weather_code']) ? $weatherData['current']['weather_code'] : 0;
        switch ($weatherCode) {
            case 0: $desc = "Clear"; break;
            case 1: $desc = "Mainly Clear"; break;
            case 2: $desc = "Partly Cloudy"; break;
            case 3: $desc = "Overcast"; break;
            case 45: $desc = "Fog"; break;
            case 48: $desc = "Rime Fog"; break;
            case 51: $desc = "Light Drizzle"; break;
            case 53: $desc = "Drizzle"; break;
            case 55: $desc = "Heavy Drizzle"; break;
            case 56: $desc = "Light Freezing Drizzle"; break;
            case 57: $desc = "Heavy Freezing Drizzle"; break;
            case 61: $desc = "Light Rain"; break;
            case 63: $desc = "Rain"; break;
            case 65: $desc = "Heavy Rain"; break;
            case 66: $desc = "Light Freezing Rain"; break;
            case 67: $desc = "Heavy Freezing Rain"; break;
            case 71: $desc = "Light Snow"; break;
            case 73: $desc = "Snow"; break;
            case 75: $desc = "Heavy Snow"; break;
            case 77: $desc = "Snow Grains"; break;
            case 80: $desc = "Light Showers"; break;
            case 81: $desc = "Showers"; break;
            case 82: $desc = "Heavy Showers"; break;
            case 85: $desc = "Light Snow Showers"; break;
            case 86: $desc = "Heavy Snow Showers"; break;
            case 95: $desc = "Thunderstorm"; break;
            case 96: $desc = "Thunderstorm w/ Light Hail"; break;
            case 99: $desc = "Thunderstorm w/ Heavy Hail"; break;
            default: $desc = "Unknown"; break;
        }
        $weatherText = round($temp * 9/5 + 32) . "°F, $desc"; // Convert to °F
    }
}
$currentTime = date("h:i A");

// End of getting weather data and time


?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Slideshow</title>
  
<style>
  body {
    margin: 0;
    background: #fff; /* Set background to white */
  }

  .slideshow-container {
    position: relative;
    width: 100vw;
    height: 100vh;
    overflow: hidden;
  }

  .slideshow-container img {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 100%;
    height: auto;
    max-height: 105%;
    object-fit: cover;
    object-position: center;
    opacity: 0;
    transition: none;

    /* Fade Transition */
    <?php if ($transition === 2): ?>
    transition: opacity 1s ease-in-out;
    <?php endif; ?>

    /* Wipe from Right */
    <?php if ($transition === 3): ?>
    left: 100%;
    opacity: 1;
    transition: left 1s ease-in-out;
    <?php endif; ?>

    /* Wipe from Left */
    <?php if ($transition === 4): ?>
    left: -100%;
    opacity: 1;
    transition: left 1s ease-in-out;
    <?php endif; ?>

    /* Wipe from Top */
    <?php if ($transition === 5): ?>
    top: -100%;
    opacity: 1;
    transition: top 1s ease-in-out;
    <?php endif; ?>

    /* Wipe from Bottom */
    <?php if ($transition === 6): ?>
    top: 100%;
    opacity: 1;
    transition: top 1s ease-in-out;
    <?php endif; ?>
  }

  .slideshow-container img.visible {
    opacity: 1;
    z-index: 2;

    /* Wipe from Right */
    <?php if ($transition === 3): ?>
    left: 50%;
    transform: translate(-50%, -50%);
    <?php endif; ?>

    /* Wipe from Left */
    <?php if ($transition === 4): ?>
    left: 50%;
    transform: translate(-50%, -50%);
    <?php endif; ?>

    /* Wipe from Top */
    <?php if ($transition === 5): ?>
    top: 50%;
    transform: translate(-50%, -50%);
    <?php endif; ?>

    /* Wipe from Bottom */
    <?php if ($transition === 6): ?>
    top: 50%;
    transform: translate(-50%, -50%);
    <?php endif; ?>
  }

  .slideshow-container img.previous {
    opacity: 0;
    z-index: 1;

    /* Wipe from Right */
    <?php if ($transition === 3): ?>
    left: -100%;
    transition: none;
    <?php endif; ?>

    /* Wipe from Left */
    <?php if ($transition === 4): ?>
    left: 100%;
    transition: none;
    <?php endif; ?>

    /* Wipe from Top */
    <?php if ($transition === 5): ?>
    top: 100%;
    transition: none;
    <?php endif; ?>

    /* Wipe from Bottom */
    <?php if ($transition === 6): ?>
    top: -100%;
    transition: none;
    <?php endif; ?>
  }

  
.overlay {
    position: absolute;
    bottom: 10px; /* At bottom, 10px from edge */
    left: 10px;
    color: white;
    font-size: 24px;
    font-family: Arial, sans-serif;
    font-weight: bold;
    background: rgba(0, 0, 0, 0.5);
    padding: 5px 10px;
    border-radius: 5px;
    z-index: 10; /* Above images */
    display: none; /* Hidden by default */
}

</style>
</head>
<body>


<div class="slideshow-container" id="slideshow">
    <div class="overlay" id="overlay" <?php echo $overlaySetting != 0 ? 'style="display: block;"' : ''; ?>>
        <?php
        switch ($overlaySetting) {
            case 0: echo ""; break; // Off
            case 1: echo $weatherText ? "$weatherText | $currentTime" : $currentTime; break; // Weather and Time
            case 2: echo $weatherText; break; // Weather Only
            case 3: echo $currentTime; break; // Time Only
        }
        ?>
    </div>
</div>
  
  <noscript>
    <p style="color: white; text-align: center;">Please enable JavaScript to view the slideshow.</p>
  </noscript>

  <script>
let images = [];
let currentIndex = 0;
let slideshowInterval;
const overlay = document.getElementById('overlay');
let weather = "<?php echo ($overlaySetting == 1 || $overlaySetting == 2) ? addslashes($weatherText) : ''; ?>"; // Initial weather if enabled
const overlaySetting = <?php echo $overlaySetting; ?>; // Pass setting to JS

// Update overlay with time and weather
function updateOverlay() {
    const time = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
    if (overlaySetting == 0) {
        overlay.style.display = 'none'; // Keep hidden
    } else {
        overlay.style.display = 'block'; // Show overlay
        switch (overlaySetting) {
            case 1: overlay.textContent = weather ? `${weather} | ${time}` : time; break; // Weather and Time
            case 2: overlay.textContent = weather; break; // Weather Only
            case 3: overlay.textContent = time; break; // Time Only
        }
    }
}
updateOverlay();
setInterval(updateOverlay, 10000); // Update time every 10 second



// Fetch weather periodically
async function fetchWeather() {
    if (overlaySetting == 1 || overlaySetting == 2) {
        try {
            const response = await fetch('weather.php');
            if (response.ok) {
                weather = await response.text();
                updateOverlay();
            }
        } catch (error) {
            console.error("Error fetching weather:", error);
            weather = ""; // Reset on error
        }
    }
}
if (overlaySetting == 1 || overlaySetting == 2) {
    setInterval(fetchWeather, 1200000); // Refresh weather every 20 minutes 1200000
}


// Fetch images dynamically from get_images.php
async function fetchImages() {
  try {
    const response = await fetch('get_images.php');
    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }
    const newImages = await response.json();
    if (JSON.stringify(images) !== JSON.stringify(newImages)) {
      images = newImages;
      startSlideshow();
    }
  } catch (error) {
    console.error("Error fetching images:", error);
  }
}

// Start the slideshow
function startSlideshow() {
  const slideshowContainer = document.getElementById('slideshow');
  const overlayElement = slideshowContainer.querySelector('.overlay'); // Preserve overlay
  slideshowContainer.innerHTML = '';
  slideshowContainer.appendChild(overlayElement); // Re-add overlay

  images.forEach((imagePath) => {
    const img = document.createElement('img');
    img.src = `slideshow/${imagePath}`;
    img.onerror = () => console.error(`Failed to load image: ${img.src}`);
    slideshowContainer.appendChild(img);
  });

  const imgElements = slideshowContainer.querySelectorAll('img');
  if (imgElements.length > 0) {
    currentIndex = 0;
    imgElements[currentIndex].classList.add('visible');

    clearInterval(slideshowInterval);
    slideshowInterval = setInterval(() => {
      const currentImg = imgElements[currentIndex];
      currentImg.classList.add('previous');
      currentImg.classList.remove('visible');
      currentIndex = (currentIndex + 1) % imgElements.length;
      imgElements[currentIndex].classList.add('visible');
      setTimeout(() => currentImg.classList.remove('previous'), 1000);
    }, <?= $delay; ?>);

    setTimeout(() => {
      fetchImages();
    }, images.length * <?= $delay; ?>);
  } else {
    slideshowContainer.innerHTML = "<p style='color:white;text-align:center;'>No images available.</p>";
    slideshowContainer.appendChild(overlayElement); // Re-add overlay even if no images
  }
}

// Initial fetch and slideshow start
fetchImages();

// Periodic image refresh
setInterval(fetchImages, 120000);

// Periodic deletion check
setInterval(function() {
  fetchDeletionSchedule();
}, 60000);

function fetchDeletionSchedule() {
  fetch('deleteFiles.php')
    .then(response => response.text())
    .then(data => console.log("Deletion check completed:", data))
    .catch(error => console.error("Error in deletion check:", error));
}
  </script>
</body>
</html>