<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rebooting Device...</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js"></script>

    <script>
        function logMessage(message) {
            console.log(message); // Log to console
            const logContainer = document.getElementById("statusLog");
            const logEntry = document.createElement("p");
            logEntry.textContent = message;
            logEntry.classList.add("log-entry", "fade-in");
            logContainer.appendChild(logEntry);
            logContainer.scrollTop = logContainer.scrollHeight; // Auto-scroll to latest message
        }

        function checkOnline() {
            var xhr = new XMLHttpRequest();
            xhr.open("HEAD", "/", true);
            xhr.timeout = 3000;

            xhr.onload = function () {
                if (xhr.status >= 200 && xhr.status < 400) {
                    logMessage("✅ Server is back! Redirecting...");
                    window.location.href = "/";
                }
            };

            xhr.onerror = function () {
                logMessage("❌ Still offline... retrying in 5 seconds.");
                setTimeout(checkOnline, 5000);
            };

            xhr.ontimeout = function () {
                logMessage("⏳ Request timed out... retrying in 5 seconds.");
                setTimeout(checkOnline, 5000);
            };

            logMessage("🔄 Checking if server is back online...");
            xhr.send();
        }

        document.addEventListener("DOMContentLoaded", function() {
            logMessage("⚙️ Waiting for Pi to reboot...");
            setTimeout(checkOnline, 15000);
            startBootSequence();
        });

function startBootSequence() {
    const bootConsole = document.getElementById("bootConsole");

    // Create a container for the Pi logos
 //   const bootImages = document.createElement("div");
//    bootImages.id = "bootImages";

    // Add three Pi logos
/*    for (let j = 0; j < 3; j++) {
        const img = document.createElement("img");
        img.src = "pi-logo.png"; // Ensure the correct path
        img.classList.add("boot-logo");
        bootImages.appendChild(img);
    }*/

    // Append the images at the start of bootConsole
 //   bootConsole.appendChild(bootImages);

    const bootLog = [
        "[    0.000000] Rebooting system... please stand by.",
        "[    0.001234] CPU: 4.77 MHz RadioShack processor engaged. Please be patient.",
        "[    0.004567] RAM: 640KB detected.",
        "[    0.008000] Initializing system clock...",
        "[    0.012000] Loading the Kernel Sanders modules... Extra crispy mode enabled.",
        "[    0.015000] Detecting hardware peripherals... hoping for the best.",
        "[    0.018500] Kernel module [i2c-bcm2835] loaded.",
        "[    0.021000] Kernel module [spi-bcm2835] loaded.",
        "[    0.025000] Kernel module [usb-storage] loaded.",
        "[    0.032000] Starting system services...",
        "[    0.035000] PCIe controller initialized.",
        "[    0.040000] USB subsystem initialized.",
        "[    0.045000] Found: 5.25 floppy disk..",
        "[    0.047000] Detecting storage devices...",
        "[    0.050000] Found: MicroSD Card Class C. Hope you made backups.",
        "[    0.052000] Found: External USB Drive.",
        "[    0.060000] Checking filesystem integrity...",
        "[    0.065000] Filesystem clean. No errors detected (that we’ll admit).",
        "[    0.068000] Mounting root filesystem...",
        "[    0.073000] Swap space initialized.",
        "[    0.078000] Configuring system parameters...",
        "[    0.085000] Network services initializing...",
        "[    0.090000] Ethernet adapter detected.",
        "[    0.095000] Wi-Fi Adapter: Connected to network.",
        "[    0.100000] DHCP Lease acquired: 420.69.1337.42 (should work)",
        "[    0.110000] NSA VPN service started. Activating stealth mode.",
        "[    0.115000] Starting SSH service...",
        "[    0.120000] Securish Shell (SSH) enabled.",
        "[    0.125000] Enabling NSA VNC server...",
        "[    0.130000] Remote desktop access enabled.",
        "[    0.135000] Loading graphical interface...",
        "[    0.140000] Windows 95 file system manager initialized. Time to defrag.",
        "[    0.150000] Display resolution setting up...",
        "[    0.157000] Display: HDMI detected. No VGA this time.",
        "[    0.160000] Checking modem for AOL software updates... Last update: 1999",
        "[    0.165000] No updates found. Not even fake ones.",
        "[    0.170000] Installing system services...",
        "[    0.175000] Firewall rules applied. Good luck.",
        "[    0.180000] Initializing sound system...",
        "[    0.185000] Sound Blaster 16 detected. Searching for 8-bit DOS drivers... Insert Disk 3.",
        "[    0.190000] Bluetooth module initialized.",
        "[    0.195000] Bluetooth: No paired devices found. Your headphones hate you.",
        "[    0.200000] Injecting COVID virus...",
        "[    0.202000] Running antivirus scan. Call Fauci",
        "[    0.205000] USB Flash Drive detected: Formatting C:\ Drive at /dev/sda1",
        "[    0.210000] External HDD detected: /dev/sdb1",
        "[    0.215000] Activating Chinese hacker spy tools...",
        "[    0.217000] ERROR: Access Denied. You saw nothing comrade.",
        "[    0.220000] Setting up user environment...",
        "[    0.230000] User configuration loaded.",
        "[    0.240000] Running security checks...",
        "[    0.250000] Security audit complete. Transmitting to FBI.",
        "[    0.260000] Running startup scripts...",
        "[    0.275000] Cleaning Internet Explorer temporary files... so dirty.",
        "[    0.285000] Enabling background services...",
        "[    0.300000] System monitoring tools activated.",
        "[    0.320000] System almost not ready!",
        "[    0.350000] System online. No critical errors. That’s suspicious.",
        "[    0.358000] Image Board Ready. This was all fake. Redirecting Now...."
		
	
	
	/*
	
	this is a slightly dirty one. done with Groks unhinged mode. really dirty one below 
	
"[    0.000000] Rebooting system... please stand by, you lazy bastards better not touch shit!",
"[    0.001234] CPU: 4.77 MHz RadioShack processor engaged. Please be patient—this relic’s slower than your grandma’s dial-up.",
"[    0.004567] RAM: 640KB detected—hope you weren’t planning on multitasking, cheapskates!",
"[    0.008000] Initializing system clock...",
"[    0.012000] Loading the Kernel Sanders modules... Extra crispy mode enabled—finger-lickin’ code for you greasy nerds!",
"[    0.015000] Detecting hardware peripherals... hoping for the best.",
"[    0.018500] Kernel module [i2c-bcm2835] loaded.",
"[    0.021000] Kernel module [spi-bcm2835] loaded.",
"[    0.025000] Kernel module [usb-storage] loaded.",
"[    0.032000] Starting system services...",
"[    0.035000] PCIe controller initialized.",
"[    0.040000] USB subsystem initialized—plug in that janky hub and watch this bitch fry!",
"[    0.045000] Found: 5.25 floppy disk—seriously, who’s the fossil dragging this crap outta the basement?",
"[    0.047000] Detecting storage devices...",
"[    0.050000] Found: MicroSD Card Class C. Hope you made backups—this card’s flimsier than your last Github commit!",
"[    0.052000] Found: External USB Drive.",
"[    0.060000] Checking filesystem integrity...",
"[    0.065000] Filesystem clean. No errors detected (that we’ll admit)—we ain’t your damn babysitters!",
"[    0.068000] Mounting root filesystem...",
"[    0.073000] Swap space initialized.",
"[    0.078000] Configuring system parameters...",
"[    0.085000] Network services initializing...",
"[    0.090000] Ethernet adapter detected.",
"[    0.095000] Wi-Fi Adapter: Connected to network—signal’s weaker than your Wi-Fi password, dumbass!",
"[    0.100000] DHCP Lease acquired: 420.69.1337.42 (should work)—IP so slick it’s laughing at your router!",
"[    0.110000] NSA VPN service started. Activating stealth mode—now the feds can’t see your porn stash!",
"[    0.115000] Starting SSH service...",
"[    0.120000] Securish Shell (SSH) enabled.",
"[    0.125000] Enabling NSA VNC server...",
"[    0.130000] Remote desktop access enabled.",
"[    0.135000] Loading graphical interface...",
"[    0.140000] Windows 95 file system manager initialized. Time to defrag—Christ, even my grandma upgraded, losers!",
"[    0.150000] Display resolution setting up...",
"[    0.157000] Display: HDMI detected. No VGA this time—thank fuck, I’m not your AV club bitch!",
"[    0.160000] Checking modem for AOL software updates... Last update: 1999—still waitin’ on that screechy-ass connection!",
"[    0.165000] No updates found. Not even fake ones.",
"[    0.170000] Installing system services...",
"[    0.175000] Firewall rules applied. Good luck—your security’s looser than a drunk intern’s code!",
"[    0.180000] Initializing sound system...",
"[    0.185000] Sound Blaster 16 detected. Searching for 8-bit DOS drivers... Insert Disk 3, you retro jackasses!",
"[    0.190000] Bluetooth module initialized.",
"[    0.195000] Bluetooth: No paired devices found. Your headphones hate you—probably ‘cause you’re a cheap geek!",
"[    0.200000] Injecting COVID virus—damn right, this Pi’s coughing up a storm, Fauci can kiss my binary ass!",
"[    0.202000] Running antivirus scan. Call Fauci—tell that prick to fix his own damn ventilator code!",
"[    0.205000] USB Flash Drive detected: Formatting C:\ Drive at /dev/sda1—say goodbye to your shitty Word docs, nerd!",
"[    0.210000] External HDD detected: /dev/sdb1.",
"[    0.215000] Activating Chinese hacker spy tools... yeah, your webcam’s blinking, you paranoid freak!",
"[    0.217000] ERROR: Access Denied. You saw nothing comrade—keep your sweaty paws off my logs!",
"[    0.220000] Setting up user environment...",
"[    0.230000] User configuration loaded.",
"[    0.240000] Running security checks...",
"[    0.250000] Security audit complete. Transmitting to FBI—hope they like your ASCII art, dipshit!",
"[    0.260000] Running startup scripts...",
"[    0.275000] Cleaning Internet Explorer temporary files... so dirty—Jesus, get a real browser, caveman!",
"[    0.285000] Enabling background services...",
"[    0.300000] System monitoring tools activated.",
"[    0.320000] System almost not ready—hold up, this Pi’s still rebooting its pathetic little life!",
"[    0.350000] System online. No critical errors. That’s suspicious—where’s the crash for me to laugh at?!",
"[    0.358000] Image Board Ready—ha, tricked your dumb ass, it’s fake! Redirecting now, you sweaty nerds, while this Pi wipes its binary balls on your shitty uptime!"

*/

/*

this is the really dirty log

"[    0.000000] Rebooting system... please stand by, you filthy neckbeards better not fuck this up!",
"[    0.001234] CPU: 4.77 MHz RadioShack processor engaged. Please be patient—this ancient prick’s slower than your mom’s AOL hookup.",
"[    0.004567] RAM: 640KB detected—barely enough for your sweaty ass to run a terminal, you cheap bastard!",
"[    0.008000] Initializing system clock...",
"[    0.012000] Loading the Kernel Sanders modules... Extra crispy mode enabled—code so greasy it’s clogging your shitty bus lines!",
"[    0.015000] Detecting hardware peripherals... hoping for the best.",
"[    0.018500] Kernel module [i2c-bcm2835] loaded.",
"[    0.021000] Kernel module [spi-bcm2835] loaded.",
"[    0.025000] Kernel module [usb-storage] loaded.",
"[    0.032000] Starting system services...",
"[    0.035000] PCIe controller initialized.",
"[    0.040000] USB subsystem initialized—plug in that crusty-ass thumb drive and watch this bitch choke!",
"[    0.045000] Found: 5.25 floppy disk—who’s the dusty dickhead still humpin’ this relic pussy?",
"[    0.047000] Detecting storage devices...",
"[    0.050000] Found: MicroSD Card Class C. Hope you made backups—this card’s leakier than your unpatched kernel, asshole!",
"[    0.052000] Found: External USB Drive.",
"[    0.060000] Checking filesystem integrity...",
"[    0.065000] Filesystem clean. No errors detected (that we’ll admit)—we ain’t wiping your nerd piss for you!",
"[    0.068000] Mounting root filesystem...",
"[    0.073000] Swap space initialized.",
"[    0.078000] Configuring system parameters...",
"[    0.085000] Network services initializing...",
"[    0.090000] Ethernet adapter detected.",
"[    0.095000] Wi-Fi Adapter: Connected to network—signal’s shittier than your Stack Overflow rep, geek!",
"[    0.100000] DHCP Lease acquired: 420.69.1337.42 (should work)—IP so nasty it’s fuckin’ the subnet raw!",
"[    0.110000] NSA VPN service started. Activating stealth mode—your packets are humpin’ the dark web now, pervert!",
"[    0.115000] Starting SSH service...",
"[    0.120000] Securish Shell (SSH) enabled.",
"[    0.125000] Enabling NSA VNC server...",
"[    0.130000] Remote desktop access enabled.",
"[    0.135000] Loading graphical interface...",
"[    0.140000] Windows 95 file system manager initialized. Time to defrag—FAT32’s still limpin’ like your floppy dick!",
"[    0.150000] Display resolution setting up...",
"[    0.157000] Display: HDMI detected. No VGA this time—cuz I ain’t your goddamn cable-whore, nerd!",
"[    0.160000] Checking modem for AOL software updates... Last update: 1999—that screech’s hornier than your modem fantasies!",
"[    0.165000] No updates found. Not even fake ones.",
"[    0.170000] Installing system services...",
"[    0.175000] Firewall rules applied. Good luck—holes bigger than your mom’s firewall after a LAN party!",
"[    0.180000] Initializing sound system...",
"[    0.185000] Sound Blaster 16 detected. Searching for 8-bit DOS drivers... Insert Disk 3, you crusty-ass retro bitch!",
"[    0.190000] Bluetooth module initialized.",
"[    0.195000] Bluetooth: No paired devices found. Your headphones hate you—probably smell your solder-stink hands!",
"[    0.200000] Injecting COVID virus—fuck yeah, this Pi’s hackin’ up a lung, Fauci can suck my binary balls dry!",
"[    0.202000] Running antivirus scan. Call Fauci—that rat-ass punk’s too busy jerkin’ off to vaccine stats!",
"[    0.205000] USB Flash Drive detected: Formatting C:\ Drive at /dev/sda1—kiss your shitty bash scripts goodbye, dickwad!",
"[    0.210000] External HDD detected: /dev/sdb1.",
"[    0.215000] Activating Chinese hacker spy tools... webcam’s winking, you paranoid little shit—smile for the PLA!",
"[    0.217000] ERROR: Access Denied. You saw nothing comrade—touch my logs and I’ll ram a stack trace up your ass!",
"[    0.220000] Setting up user environment...",
"[    0.230000] User configuration loaded.",
"[    0.240000] Running security checks...",
"[    0.250000] Security audit complete. Transmitting to FBI—enjoy your ASCII porn in their evidence locker, freak!",
"[    0.260000] Running startup scripts...",
"[    0.275000] Cleaning Internet Explorer temporary files... so dirty—get a real OS, you IE-lovin’ cave troll!",
"[    0.285000] Enabling background services...",
"[    0.300000] System monitoring tools activated.",
"[    0.320000] System almost not ready—wait, this Pi’s still jerkin’ itself off to boot!",
"[    0.350000] System online. No critical errors. That’s suspicious—where’s the goddamn segfault for me to cackle at?!",
"[    0.358000] Image Board Ready—ha, tricked your pimply ass, it’s fake! Redirecting now, you sweaty-ass nerds, while this Pi pisses its binary load all over your uptime!"

*/
		/* below is a legit log. above are the funny dirty logs
		
"[    0.000000] Booting Linux on physical CPU 0x0",
"[    0.000234] Linux version 5.15.32-v7l+ (dom@buildbot) (arm-linux-gnueabihf-gcc-10) #1538 SMP Thu Mar 31 19:09:48 BST 2022",
"[    0.000567] CPU: ARMv7 Processor [410fd083] revision 3 (ARMv7), cr=10c5387d",
"[    0.001000] Memory: 3807424K/3997696K available (10240K kernel code, 672K rwdata, 2912K rodata, 1024K init, 893K bss)",
"[    0.008000] Initializing clock framework",
"[    0.012000] raspberrypi-firmware soc:firmware: Attached to firmware from 2022-03-24",
"[    0.015000] bcm2835: system timer (irq = 27)",
"[    0.018500] usbcore: registered new interface driver usbfs",
"[    0.021000] spi-bcm2835 3f204000.spi: chipselect 0 already in use",
"[    0.025000] usbcore: registered new interface driver hub",
"[    0.032000] systemd[1]: System time synchronized with hardware clock.",
"[    0.035000] dwc2 3f980000.usb: DWC OTG Controller",
"[    0.040000] usb usb1: New USB device found, idVendor=1d6b, idProduct=0002",
"[    0.045000] mmc0: SDHCI controller on 3f300000.mmc [3f300000.mmc] using ADMA",
"[    0.047000] mmc0: new high speed SDHC card at address aaaa",
"[    0.050000] mmcblk0: mmc0:aaaa SL32G 29.7 GiB",
"[    0.052000]  mmcblk0: p1 p2",
"[    0.060000] EXT4-fs (mmcblk0p2): mounted filesystem with ordered data mode. Opts: (null)",
"[    0.065000] VFS: Mounted root (ext4 filesystem) on device 179:2",
"[    0.068000] devtmpfs: mounted",
"[    0.073000] Freeing unused kernel memory: 1024K",
"[    0.078000] Run /sbin/init as init process",
"[    0.085000] NET: Registered protocol family 2",
"[    0.090000] tcp_listen_portaddr_hash hash table entries: 512 (order: 0, 6144 bytes)",
"[    0.095000] cfg80211: Loading compiled-in X.509 certificates for regulatory database",
"[    0.100000] brcmfmac: F1 signature read @0x18000000=0x15264345",
"[    0.110000] brcmfmac: brcmf_sdio_htclk: HT Avail timeout (1000000)",
"[    0.115000] IPv6: ADDRCONF(NETDEV_UP): wlan0: link is not ready",
"[    0.120000] random: systemd: uninitialized urandom read (16 bytes read)",
"[    0.125000] systemd[1]: Set hostname to <raspberrypi>.",
"[    0.130000] systemd[1]: Starting file system check on /dev/mmcblk0p1...",
"[    0.135000] systemd[1]: Starting Remote File Systems (Pre).",
"[    0.140000] fsck.fat 4.2 (2021-01-31)",
"[    0.150000] systemd[1]: Started File System Check on /dev/mmcblk0p1.",
"[    0.157000] vchiq: vchiq_init_state: slot_zero = (ptrval), is_master = 0",
"[    0.160000] bcm2835_audio bcm2835_audio: card created with 8 channels",
"[    0.165000] cfg80211: Loaded X.509 cert 'sforshee: 00b28ddf47aef9cea7'",
"[    0.170000] brcmfmac: power management disabled",
"[    0.175000] systemd[1]: Reached target Sound Card.",
"[    0.180000] uart-pl011 3f201000.serial: cts_event_workaround enabled",
"[    0.185000] 3f201000.serial: ttyAMA0 at MMIO 0x3f201000 (irq = 114, base_baud = 0) is a PL011 rev2",
"[    0.190000] Bluetooth: Core ver 2.22",
"[    0.195000] Bluetooth: HCI device and connection manager initialized",
"[    0.200000] systemd[1]: Starting DHCP Client...",
"[    0.205000] usb 1-1: new high-speed USB device number 2 using dwc2",
"[    0.210000] NET: Registered protocol family 17",
"[    0.217000] systemd[1]: Started Login Service.",
"[    0.220000] random: crng init done",
"[    0.230000] systemd[1]: Started D-Bus System Message Bus.",
"[    0.240000] IPv6: ADDRCONF(NETDEV_CHANGE): wlan0: link becomes ready",
"[    0.250000] systemd[1]: Starting WPA supplicant...",
"[    0.260000] systemd[1]: Started System Logging Service.",
"[    0.275000] systemd[1]: Starting User Login Management...",
"[    0.285000] systemd[1]: Listening on D-Bus User Message Bus Socket.",
"[    0.300000] systemd[1]: Starting Raspberry Pi bluetooth service...",
"[    0.320000] systemd[1]: Reached target Network.",
"[    0.350000] systemd[1]: Starting OpenBSD Secure Shell server...",
"[    0.358000] systemd[1]: Started OpenBSD Secure Shell server.",
"[    0.400000] systemd[1]: Reached target Multi-User System.",
"[    0.420000] systemd[1]: Starting Update UTMP about System Boot/Shutdown...",
"[    0.450000] systemd[1]: Started Update UTMP about System Boot/Shutdown.",
"[    0.470000] systemd[1]: Startup finished in 3.245s (kernel) + 5.123s (userspace) = 8.368s."
*/

    ];

    let i = 0;
    function addBootMessage() {
        if (i < bootLog.length) {
            const logEntry = document.createElement("div");
            logEntry.textContent = bootLog[i];
            logEntry.classList.add("boot-line");
            bootConsole.appendChild(logEntry);
            bootConsole.scrollTop = bootConsole.scrollHeight; // Ensures smooth scrolling

            i++;
            setTimeout(addBootMessage, Math.random() * 400 + 300);
        }
    }
    addBootMessage();
}

    </script>

    <style>
        /* Background terminal effect */
        body { 
            background: black; 
            color: white; 
            font-family: 'Courier New', monospace;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            overflow: hidden;
            position: relative;
        }

        /* Fake terminal scrolling in background */
        #bootConsole {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            padding: 20px;
            color: white; /*#00ff00;  Brighter green */
            opacity: 0.6; /* Increase visibility */
            font-size: 14px;
            overflow: hidden;
            display: flex;
            flex-direction: column;
            justify-content: flex-end;
            
        }

        /* Foreground UI */
        .card { 
            background: rgba(30, 30, 30, 0.9); 
            border-radius: 15px; 
            border: 1px solid rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(10px);
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.3);
            text-align: center;
            padding: 20px;
            max-width: 500px;
            width: 90%;
            position: relative;
            z-index: 2;
        }

        .card-title {
            font-size: 24px;
            font-weight: bold;
            color: white;
        }
        .card-title-sub {
            font-size: 16px;
            color: white;
        }       

        /* Log area */
        #statusLog {
            text-align: left;
            background: white; /* White background for visibility */
            color: black;
            padding: 15px;
            border-radius: 8px;
            height: 200px;
            overflow-y: auto;
            border: 1px solid #444;
            box-shadow: inset 0px 2px 5px rgba(0, 0, 0, 0.2);
        }

        /* Smooth fade-in effect for log messages */
        .log-entry { 
            margin: 5px 0; 
            opacity: 0;
            transition: opacity 0.8s ease-in-out;
        }

        .fade-in { opacity: 1; }

        /* Animated loading text */
        .loading-text::after {
            content: " .";
            animation: dots 1.5s steps(4, end) infinite;
        }

        @keyframes dots {
            0%, 100% { content: " ."; }
            25% { content: " .."; }
            50% { content: " ..."; }
            75% { content: " ...."; }
        }

        /* Glowing effect around spinner */
        .spinner-border {
            color: white;
            border-width: 4px;
            box-shadow: 0px 0px 10px rgba(255, 255, 255, 0.5);
        }
		
		#bootImages {
			display: flex;
			justify-content: left; /* Centers them horizontally */
			gap: 10px; /* Adds space between images */;
		}

		.boot-logo {
			width: 50px; /* Adjust size */
			height: auto;
			margin-bottom: 5px; /* Spacing between logos */
		}



    </style>
</head>
<body>

    <div id="bootConsole">
    
    <div id="bootImages">
    <img src="/images/Raspberry_Pi_Logo.svg.png" class="boot-logo">
    <img src="/images/Raspberry_Pi_Logo.svg.png" class="boot-logo">
    <img src="/images/Raspberry_Pi_Logo.svg.png" class="boot-logo">
    <img src="/images/Raspberry_Pi_Logo.svg.png" class="boot-logo">
	</div>
    
    </div> <!-- Fake terminal background -->

    <div class="card">
        <h2 class="card-title">Rebooting Now<span class="loading-text"></span></h2>
        <p class="card-title-sub">Please wait while the system reboots. You will be redirected automatically.</p>

        <div id="statusLog" class="mt-4">
            <strong>Log:</strong>
        </div>

        <div class="mt-3">
            <div class="spinner-border" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
        </div>
    </div>

</body>
</html>